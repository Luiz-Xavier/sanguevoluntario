

  document.write("Agora são: ",Date());
