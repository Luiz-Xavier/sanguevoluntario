

  document.getElementsByClassName('box1').addEventListener('click',function(){
    return document.location = "/views/pause.html";

  });

  document.getElementsByClassName('box2').addEventListener('click',function(){
    return document.location = "/views/cadastro.html";

  });

  document.getElementsByClassName('box3').addEventListener('click',function(){
    return document.location = "/views/principal.html";

  });